-- Seed admin user (password: admin123 - hashed with bcrypt)
INSERT INTO users (id, email, password, name, role) VALUES
  ('admin-001', 'admin@sweetshop.com', '$2b$10$rKvVVH8TQhF0cLwQGKqGCOxK4K1qN8pJ4QyQh5vN8nYy5xD7xJ7Ky', 'Admin User', 'admin');

-- Updated with Indian sweets and INR prices
-- Seed sample Indian sweets
INSERT INTO sweets (id, name, category, price, quantity, description, image_url) VALUES
  ('sweet-001', 'Gulab Jamun', 'Milk-Based', 120, 80, 'Soft milk-solid balls deep-fried and soaked in rose-flavored sugar syrup', '/placeholder.svg?height=200&width=200'),
  ('sweet-002', 'Rasgulla', 'Milk-Based', 100, 100, 'Spongy cottage cheese balls soaked in light sugar syrup', '/placeholder.svg?height=200&width=200'),
  ('sweet-003', 'Jalebi', 'Fried', 80, 120, 'Crispy pretzel-shaped sweet soaked in saffron-flavored sugar syrup', '/placeholder.svg?height=200&width=200'),
  ('sweet-004', 'Barfi', 'Milk-Based', 150, 60, 'Dense milk-based sweet with cardamom and pistachios', '/placeholder.svg?height=200&width=200'),
  ('sweet-005', 'Ladoo', 'Flour-Based', 90, 150, 'Round balls made from flour, ghee, and sugar with aromatic spices', '/placeholder.svg?height=200&width=200'),
  ('sweet-006', 'Rasmalai', 'Milk-Based', 180, 50, 'Soft paneer patties in creamy, saffron-flavored milk', '/placeholder.svg?height=200&width=200'),
  ('sweet-007', 'Mysore Pak', 'Flour-Based', 130, 70, 'Rich, buttery sweet made with gram flour and pure ghee', '/placeholder.svg?height=200&width=200'),
  ('sweet-008', 'Kaju Katli', 'Dry Fruit', 250, 40, 'Premium cashew fudge with edible silver leaf', '/placeholder.svg?height=200&width=200');
