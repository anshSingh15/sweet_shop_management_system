# API Testing Guide

This document provides examples of how to test the Sweet Shop Management API endpoints using various tools.

## Using cURL

### Authentication

**Register a new user:**
\`\`\`bash
curl -X POST http://localhost:3000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "email": "test@example.com",
    "password": "password123",
    "name": "Test User"
  }'
\`\`\`

**Login:**
\`\`\`bash
curl -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "test@example.com",
    "password": "password123"
  }'
\`\`\`

Save the token from the response for authenticated requests.

### Sweet Management

**Get all sweets:**
\`\`\`bash
curl http://localhost:3000/api/sweets
\`\`\`

**Search sweets:**
\`\`\`bash
curl "http://localhost:3000/api/sweets/search?category=chocolate&minPrice=5&maxPrice=15"
\`\`\`

**Create a sweet (requires admin token):**
\`\`\`bash
curl -X POST http://localhost:3000/api/sweets \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_ADMIN_TOKEN" \
  -d '{
    "name": "New Candy",
    "category": "Chocolate",
    "price": 15.99,
    "quantity": 100,
    "description": "A delicious new candy"
  }'
\`\`\`

**Purchase a sweet (requires user token):**
\`\`\`bash
curl -X POST http://localhost:3000/api/sweets/SWEET_ID/purchase \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_USER_TOKEN" \
  -d '{
    "quantity": 2
  }'
\`\`\`

**Restock a sweet (requires admin token):**
\`\`\`bash
curl -X POST http://localhost:3000/api/sweets/SWEET_ID/restock \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_ADMIN_TOKEN" \
  -d '{
    "quantity": 50
  }'
\`\`\`

## Using Postman

1. **Create a new collection** named "Sweet Shop API"

2. **Add environment variables:**
   - `base_url`: http://localhost:3000
   - `user_token`: (will be set after login)
   - `admin_token`: (will be set after admin login)

3. **Import these requests:**

### Auth Requests

**Register:**
- Method: POST
- URL: `{{base_url}}/api/auth/register`
- Body (JSON):
\`\`\`json
{
  "email": "test@example.com",
  "password": "password123",
  "name": "Test User"
}
\`\`\`

**Login:**
- Method: POST
- URL: `{{base_url}}/api/auth/login`
- Body (JSON):
\`\`\`json
{
  "email": "test@example.com",
  "password": "password123"
}
\`\`\`
- Tests (save token):
\`\`\`javascript
pm.environment.set("user_token", pm.response.json().token);
\`\`\`

### Sweet Requests

**List Sweets:**
- Method: GET
- URL: `{{base_url}}/api/sweets`

**Search Sweets:**
- Method: GET
- URL: `{{base_url}}/api/sweets/search?category=chocolate`

**Create Sweet:**
- Method: POST
- URL: `{{base_url}}/api/sweets`
- Headers: `Authorization: Bearer {{admin_token}}`
- Body (JSON):
\`\`\`json
{
  "name": "Test Candy",
  "category": "Test",
  "price": 9.99,
  "quantity": 50
}
\`\`\`

## Using Jest Tests

Run the included test suite:

\`\`\`bash
# Run all tests
npm test

# Run specific test file
npm test -- __tests__/api/auth.test.ts

# Run with coverage
npm run test:coverage
\`\`\`

## Expected Response Codes

| Code | Meaning | Usage |
|------|---------|-------|
| 200 | OK | Successful GET, PUT, DELETE |
| 201 | Created | Successful POST (resource created) |
| 400 | Bad Request | Invalid input/validation error |
| 401 | Unauthorized | Missing or invalid token |
| 403 | Forbidden | Valid token but insufficient permissions |
| 404 | Not Found | Resource doesn't exist |
| 500 | Server Error | Internal server error |

## Error Response Format

All errors follow this format:

\`\`\`json
{
  "success": false,
  "error": "Description of the error"
}
\`\`\`

## Testing Checklist

- [ ] User can register with valid data
- [ ] Registration fails with duplicate email
- [ ] User can login with correct credentials
- [ ] Login fails with incorrect credentials
- [ ] Unauthenticated users can view sweets
- [ ] Authenticated users can purchase sweets
- [ ] Purchase fails when quantity exceeds stock
- [ ] Admin can create new sweets
- [ ] Admin can update existing sweets
- [ ] Admin can delete sweets
- [ ] Admin can restock sweets
- [ ] Non-admin cannot access admin endpoints
- [ ] Search filters work correctly
- [ ] JWT tokens expire appropriately
