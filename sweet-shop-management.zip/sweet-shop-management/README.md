# Sweet Shop Management System

A full-stack web application for managing a sweet shop, built with Next.js, TypeScript, and Test-Driven Development (TDD) principles. This system allows users to browse and purchase Indian sweets while providing administrators with comprehensive inventory management tools.

![Sweet Shop Management System](public/screenshot-main.png)

## Features

### User Features
- User registration and authentication with JWT tokens
- Browse catalog of available Indian sweets
- Search and filter sweets by name, category, and price range
- Purchase sweets with real-time inventory updates
- Secure password storage with bcrypt hashing

### Admin Features
- Add, edit, and delete sweets from the catalog
- Manage inventory with restock functionality
- View all sweets with current stock levels
- Protected admin-only routes and operations

### Technical Features
- RESTful API with comprehensive endpoints
- Token-based authentication (JWT)
- Test-Driven Development with high test coverage
- Responsive design that works on all devices
- Type-safe TypeScript implementation
- Clean architecture with dependency injection

## Tech Stack

### Frontend
- **Framework**: Next.js 16 (App Router)
- **Language**: TypeScript
- **UI Library**: React 19
- **Styling**: Tailwind CSS v4
- **Components**: Radix UI (shadcn/ui)
- **State Management**: Zustand
- **Icons**: Lucide React

### Backend
- **Runtime**: Node.js
- **Framework**: Next.js API Routes
- **Authentication**: JWT (jose library)
- **Password Hashing**: bcryptjs
- **Database**: Mock implementation (ready for PostgreSQL/MySQL/SQLite)

### Testing
- **Framework**: Jest
- **Testing Library**: React Testing Library
- **Coverage**: 70%+ threshold on all metrics

## Project Structure

\`\`\`
sweet-shop-management/
├── app/                          # Next.js app directory
│   ├── api/                      # API routes
│   │   ├── auth/                 # Authentication endpoints
│   │   │   ├── register/         # POST /api/auth/register
│   │   │   └── login/            # POST /api/auth/login
│   │   └── sweets/               # Sweet management endpoints
│   │       ├── route.ts          # GET, POST /api/sweets
│   │       ├── search/           # GET /api/sweets/search
│   │       └── [id]/             # GET, PUT, DELETE /api/sweets/:id
│   │           ├── purchase/     # POST /api/sweets/:id/purchase
│   │           └── restock/      # POST /api/sweets/:id/restock
│   ├── page.tsx                  # Main application page
│   ├── layout.tsx                # Root layout
│   └── globals.css               # Global styles
├── components/                   # React components
│   ├── auth/                     # Authentication forms
│   ├── admin/                    # Admin-only components
│   ├── ui/                       # Reusable UI components (shadcn)
│   └── sweet-card.tsx           # Sweet display card
├── lib/                          # Core library code
│   ├── api/                      # API client
│   ├── db/                       # Database layer
│   │   ├── schema.ts            # Database schema definitions
│   │   └── mock-db.ts           # Mock database implementation
│   ├── middleware/              # Authentication middleware
│   ├── hooks/                   # Custom React hooks
│   └── utils/                   # Utility functions
│       ├── jwt.ts               # JWT token utilities
│       └── password.ts          # Password hashing utilities
├── scripts/                     # Database scripts
│   ├── 001_create_tables.sql   # Table creation script
│   └── 002_seed_data.sql       # Sample data seed script
├── __tests__/                   # Test files (mirrors src structure)
│   ├── api/                     # API endpoint tests
│   └── lib/                     # Library unit tests
├── .github/                     # GitHub configuration
│   └── workflows/               # CI/CD workflows
│       └── test.yml             # Automated testing workflow
├── jest.config.js              # Jest configuration
├── jest.setup.js               # Jest setup file
└── package.json                # Project dependencies
\`\`\`

## API Documentation

### Authentication Endpoints

#### POST /api/auth/register
Register a new user account.

**Request Body:**
\`\`\`json
{
  "email": "user@example.com",
  "password": "securepassword123",
  "name": "John Doe"
}
\`\`\`

**Response (201):**
\`\`\`json
{
  "success": true,
  "user": {
    "id": "uuid",
    "email": "user@example.com",
    "name": "John Doe",
    "role": "user",
    "createdAt": "2024-01-01T00:00:00.000Z"
  },
  "token": "jwt_token_here"
}
\`\`\`

#### POST /api/auth/login
Login to an existing account.

**Request Body:**
\`\`\`json
{
  "email": "user@example.com",
  "password": "securepassword123"
}
\`\`\`

**Response (200):**
\`\`\`json
{
  "success": true,
  "user": {
    "id": "uuid",
    "email": "user@example.com",
    "name": "John Doe",
    "role": "user"
  },
  "token": "jwt_token_here"
}
\`\`\`

### Sweet Management Endpoints

#### GET /api/sweets
Get all sweets (Public).

**Response (200):**
\`\`\`json
{
  "success": true,
  "sweets": [
    {
      "id": "uuid",
      "name": "Chocolate Truffles",
      "category": "Chocolate",
      "price": 12.99,
      "quantity": 50,
      "description": "Rich dark chocolate truffles",
      "createdAt": "2024-01-01T00:00:00.000Z"
    }
  ]
}
\`\`\`

#### POST /api/sweets
Create a new sweet (Admin only).

**Headers:** `Authorization: Bearer {token}`

**Request Body:**
\`\`\`json
{
  "name": "New Candy",
  "category": "Chocolate",
  "price": 15.99,
  "quantity": 100,
  "description": "Delicious new candy"
}
\`\`\`

**Response (201):**
\`\`\`json
{
  "success": true,
  "sweet": { /* sweet object */ }
}
\`\`\`

#### GET /api/sweets/search
Search sweets by various criteria (Public).

**Query Parameters:**
- `name` (optional): Filter by name (case-insensitive)
- `category` (optional): Filter by category
- `minPrice` (optional): Minimum price
- `maxPrice` (optional): Maximum price

**Example:** `/api/sweets/search?category=chocolate&minPrice=5&maxPrice=15`

**Response (200):**
\`\`\`json
{
  "success": true,
  "sweets": [ /* filtered sweets */ ],
  "count": 5
}
\`\`\`

#### PUT /api/sweets/:id
Update a sweet (Admin only).

**Headers:** `Authorization: Bearer {token}`

**Request Body:**
\`\`\`json
{
  "price": 19.99,
  "quantity": 75
}
\`\`\`

#### DELETE /api/sweets/:id
Delete a sweet (Admin only).

**Headers:** `Authorization: Bearer {token}`

**Response (200):**
\`\`\`json
{
  "success": true,
  "message": "Sweet deleted successfully"
}
\`\`\`

#### POST /api/sweets/:id/purchase
Purchase a sweet (Authenticated users).

**Headers:** `Authorization: Bearer {token}`

**Request Body:**
\`\`\`json
{
  "quantity": 2
}
\`\`\`

**Response (200):**
\`\`\`json
{
  "success": true,
  "sweet": { /* updated sweet with new quantity */ },
  "message": "Successfully purchased 2 Chocolate Truffles"
}
\`\`\`

#### POST /api/sweets/:id/restock
Restock a sweet (Admin only).

**Headers:** `Authorization: Bearer {token}`

**Request Body:**
\`\`\`json
{
  "quantity": 50
}
\`\`\`

**Response (200):**
\`\`\`json
{
  "success": true,
  "sweet": { /* updated sweet with new quantity */ },
  "message": "Successfully restocked 50 Chocolate Truffles"
}
\`\`\`

## Setup Instructions

### Prerequisites
- Node.js 18.x or higher
- npm or yarn package manager
- Git

### Installation

1. **Clone the repository**
   \`\`\`bash
   git clone <repository-url>
   cd sweet-shop-management
   \`\`\`

2. **Install dependencies**
   \`\`\`bash
   npm install
   \`\`\`

3. **Set up environment variables** (REQUIRED)
   
   Create a `.env.local` file in the root directory:
   \`\`\`env
   # JWT Secret for token signing (REQUIRED)
   # Generate a secure random string with: openssl rand -base64 32
   NEXTAUTH_SECRET=your-super-secret-jwt-key-change-this-in-production-use-openssl-rand
   
   # Alternative JWT secret (fallback if NEXTAUTH_SECRET is not set)
   JWT_SECRET=your-super-secret-jwt-key-change-this-in-production
   
   # Database Configuration (when using real database)
   # DATABASE_URL=postgresql://user:password@localhost:5432/sweetshop
   \`\`\`

   **Generate a secure JWT secret:**
   \`\`\`bash
   # On Linux/Mac
   openssl rand -base64 32
   
   # On Windows (PowerShell)
   [Convert]::ToBase64String((1..32 | ForEach-Object { Get-Random -Maximum 256 }))
   
   # Or use an online generator
   # https://generate-secret.vercel.app/32
   \`\`\`

4. **Run the development server**
   \`\`\`bash
   npm run dev
   \`\`\`

5. **Open your browser**
   
   Navigate to [http://localhost:3000](http://localhost:3000)

### Default Credentials

The application comes with a pre-seeded admin account:
- **Email**: admin@sweetshop.com
- **Password**: admin123

**Important**: Change this password in production!

## Running Tests

### Run all tests
\`\`\`bash
npm test
\`\`\`

### Run tests with coverage
\`\`\`bash
npm run test:coverage
\`\`\`

### Run tests in CI mode
\`\`\`bash
npm run test:ci
\`\`\`

### Test Structure
- Unit tests for all utilities (JWT, password hashing, database operations)
- Integration tests for all API endpoints
- Middleware tests for authentication and authorization
- 70%+ coverage threshold enforced

## Development Workflow

This project was built using Test-Driven Development (TDD) principles:

1. **Red**: Write failing tests first
2. **Green**: Implement minimum code to pass tests
3. **Refactor**: Improve code while keeping tests green

### Git Commit Guidelines

This project follows semantic commit messages:
- `feat:` New features
- `fix:` Bug fixes
- `test:` Adding or updating tests
- `refactor:` Code refactoring
- `docs:` Documentation changes
- `style:` Code style changes (formatting)
- `chore:` Maintenance tasks

## Database Migration

The current implementation uses a mock in-memory database for development. To migrate to a production database:

1. **Choose your database** (PostgreSQL, MySQL, or SQLite)

2. **Install database client**
   \`\`\`bash
   # For PostgreSQL
   npm install pg

   # For MySQL
   npm install mysql2

   # For SQLite
   npm install better-sqlite3
   \`\`\`

3. **Update database implementation**
   
   Create a new implementation of the `Database` interface in `lib/db/` that connects to your chosen database.

4. **Run migration scripts**
   
   Execute the SQL scripts in the `scripts/` folder:
   - `001_create_tables.sql` - Creates all necessary tables
   - `002_seed_data.sql` - Seeds initial data

5. **Update dependency injection**
   
   Replace the mock database import with your new implementation throughout the codebase.

## Deployment

### Deploy to Vercel

1. **Push to GitHub**
   \`\`\`bash
   git push origin main
   \`\`\`

2. **Import to Vercel**
   - Go to [vercel.com](https://vercel.com)
   - Import your repository
   - Configure environment variables in Vercel dashboard
   - Deploy

3. **Set production environment variables**
   
   In Vercel dashboard, add these environment variables:
   - `NEXTAUTH_SECRET`: Strong random secret (use `openssl rand -base64 32`)
   - `JWT_SECRET`: Fallback secret (same as NEXTAUTH_SECRET)
   - Add database connection strings if using a real database (e.g., `DATABASE_URL`)

### Environment Variables Reference

| Variable | Required | Description | Example |
|----------|----------|-------------|---------|
| `NEXTAUTH_SECRET` | Yes | Primary JWT signing secret | Generated via `openssl rand -base64 32` |
| `JWT_SECRET` | No | Fallback JWT signing secret | Same as NEXTAUTH_SECRET |
| `DATABASE_URL` | No | Database connection string (for production) | `postgresql://user:pass@host:5432/db` |

### Security Best Practices

1. **Never commit `.env.local` files** - These contain secrets and should be in `.gitignore`
2. **Use strong secrets** - Generate random secrets at least 32 characters long
3. **Different secrets per environment** - Use different secrets for dev, staging, and production
4. **Rotate secrets regularly** - Change JWT secrets periodically in production
5. **Use environment variables** - Never hardcode secrets in source code

## Future Enhancements

- [ ] Implement real database (PostgreSQL/MySQL)
- [ ] Add user purchase history page
- [ ] Implement shopping cart functionality
- [ ] Add payment integration (Stripe/PayPal)
- [ ] Create admin analytics dashboard
- [ ] Add product images upload
- [ ] Implement email notifications
- [ ] Add product reviews and ratings
- [ ] Create mobile app version
- [ ] Add multi-language support

## Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Write tests for your changes
4. Implement your changes
5. Ensure all tests pass (`npm test`)
6. Commit your changes with semantic commit messages
7. Push to the branch (`git push origin feature/amazing-feature`)
8. Open a Pull Request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Author

Built with TDD principles and modern web technologies as part of a technical assessment.

## Acknowledgments

- Next.js team for the excellent framework
- Vercel for hosting and AI tools
- shadcn for the beautiful UI components
- The open-source community for amazing libraries

---

**Note**: This is a demonstration project built for a technical assessment. The mock database is suitable for development but should be replaced with a production database for real-world use.
