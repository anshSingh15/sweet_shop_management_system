"use client"

import { useState } from "react"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ShoppingCart, Package, Pencil, Trash2 } from "lucide-react"
import { apiClient } from "@/lib/api/client"
import { useAuth } from "@/lib/hooks/use-auth"

interface SweetCardProps {
  sweet: {
    id: string
    name: string
    category: string
    price: number
    quantity: number
    description?: string
    imageUrl?: string
  }
  onUpdate?: () => void
  onEdit?: (sweet: any) => void
  onDelete?: (id: string) => void
}

export function SweetCard({ sweet, onUpdate, onEdit, onDelete }: SweetCardProps) {
  const [purchasing, setPurchasing] = useState(false)
  const [quantity, setQuantity] = useState(1)
  const { user, isAuthenticated } = useAuth()
  const isAdmin = user?.role === "admin"

  const handlePurchase = async () => {
    if (!isAuthenticated) {
      alert("Please login to purchase")
      return
    }

    setPurchasing(true)
    try {
      await apiClient.purchaseSweet(sweet.id, quantity)
      alert(`Successfully purchased ${quantity} ${sweet.name}!`)
      onUpdate?.()
    } catch (err: any) {
      alert(err.message || "Failed to purchase")
    } finally {
      setPurchasing(false)
    }
  }

  return (
    <Card className="overflow-hidden hover:shadow-xl transition-all duration-300 border-2 group">
      <div className="aspect-square overflow-hidden bg-muted relative">
        <img
          src={sweet.imageUrl || `/placeholder.svg?height=300&width=300&query=${encodeURIComponent(sweet.name)}`}
          alt={sweet.name}
          className="object-cover w-full h-full group-hover:scale-110 transition-transform duration-300"
        />
        <Badge className="absolute top-3 right-3 bg-accent text-accent-foreground font-bold">
          ₹{sweet.price.toFixed(2)}
        </Badge>
      </div>
      <CardHeader>
        <div className="flex justify-between items-start gap-2">
          <CardTitle className="text-xl text-balance">{sweet.name}</CardTitle>
          <Badge variant="secondary" className="shrink-0">
            {sweet.category}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        {sweet.description && <p className="text-sm text-muted-foreground line-clamp-2">{sweet.description}</p>}
        <div className="flex items-center gap-2 text-sm">
          <Package className="h-4 w-4" />
          <span className={sweet.quantity === 0 ? "text-destructive font-semibold" : "text-muted-foreground"}>
            {sweet.quantity === 0 ? "Out of Stock" : `${sweet.quantity} in stock`}
          </span>
        </div>
      </CardContent>
      <CardFooter className="flex gap-2">
        {isAdmin ? (
          <>
            <Button variant="outline" size="sm" className="flex-1 bg-transparent" onClick={() => onEdit?.(sweet)}>
              <Pencil className="h-4 w-4 mr-1" />
              Edit
            </Button>
            <Button variant="destructive" size="sm" onClick={() => onDelete?.(sweet.id)}>
              <Trash2 className="h-4 w-4" />
            </Button>
          </>
        ) : (
          <>
            <input
              type="number"
              min="1"
              max={sweet.quantity}
              value={quantity}
              onChange={(e) => setQuantity(Number(e.target.value))}
              className="w-16 px-2 py-1 border rounded-lg text-center"
              disabled={sweet.quantity === 0}
            />
            <Button className="flex-1" disabled={sweet.quantity === 0 || purchasing} onClick={handlePurchase}>
              <ShoppingCart className="h-4 w-4 mr-2" />
              {purchasing ? "Processing..." : "Purchase"}
            </Button>
          </>
        )}
      </CardFooter>
    </Card>
  )
}
