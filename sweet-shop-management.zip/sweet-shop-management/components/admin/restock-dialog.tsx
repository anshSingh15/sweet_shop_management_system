"use client"

import type React from "react"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { apiClient } from "@/lib/api/client"

interface RestockDialogProps {
  open: boolean
  onClose: () => void
  onSuccess: () => void
  sweet?: any
}

export function RestockDialog({ open, onClose, onSuccess, sweet }: RestockDialogProps) {
  const [quantity, setQuantity] = useState("")
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!sweet) return

    setLoading(true)
    try {
      await apiClient.restockSweet(sweet.id, Number(quantity))
      onSuccess()
      onClose()
      setQuantity("")
    } catch (err: any) {
      alert(err.message || "Failed to restock")
    } finally {
      setLoading(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-sm">
        <DialogHeader>
          <DialogTitle>Restock {sweet?.name}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit}>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="quantity">Quantity to Add</Label>
              <Input
                id="quantity"
                type="number"
                min="1"
                value={quantity}
                onChange={(e) => setQuantity(e.target.value)}
                required
                disabled={loading}
                placeholder="Enter quantity"
              />
            </div>
            {sweet && <p className="text-sm text-muted-foreground">Current stock: {sweet.quantity}</p>}
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose} disabled={loading}>
              Cancel
            </Button>
            <Button type="submit" disabled={loading}>
              {loading ? "Restocking..." : "Restock"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
