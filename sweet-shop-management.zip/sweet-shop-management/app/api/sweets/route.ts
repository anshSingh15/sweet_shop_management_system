// List all sweets and create new sweet

import { type NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db/mock-db"
import { requireAdmin } from "@/lib/middleware/auth"

// GET /api/sweets - List all sweets (public)
export async function GET(request: NextRequest) {
  try {
    const sweets = await db.findAllSweets()

    return NextResponse.json({
      success: true,
      sweets,
    })
  } catch (error) {
    console.error("[v0] Error fetching sweets:", error)
    return NextResponse.json({ success: false, error: "Failed to fetch sweets" }, { status: 500 })
  }
}

// POST /api/sweets - Create new sweet (admin only)
export async function POST(request: NextRequest) {
  try {
    // Check admin authorization
    const authResult = await requireAdmin(request)
    if (!authResult.authorized) {
      return NextResponse.json({ success: false, error: "Admin access required" }, { status: 403 })
    }

    const body = await request.json()
    const { name, category, price, quantity, description, imageUrl } = body

    // Validation
    if (!name || !category || price === undefined || quantity === undefined) {
      return NextResponse.json({ success: false, error: "Missing required fields" }, { status: 400 })
    }

    if (price < 0 || quantity < 0) {
      return NextResponse.json({ success: false, error: "Price and quantity must be non-negative" }, { status: 400 })
    }

    // Create sweet
    const sweet = await db.createSweet({
      name,
      category,
      price: Number(price),
      quantity: Number(quantity),
      description,
      imageUrl,
    })

    return NextResponse.json(
      {
        success: true,
        sweet,
      },
      { status: 201 },
    )
  } catch (error) {
    console.error("[v0] Error creating sweet:", error)
    return NextResponse.json({ success: false, error: "Failed to create sweet" }, { status: 500 })
  }
}
