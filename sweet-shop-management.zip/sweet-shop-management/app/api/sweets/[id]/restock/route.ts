// Restock sweet (increases quantity) - Admin only

import { type NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db/mock-db"
import { requireAdmin } from "@/lib/middleware/auth"

// POST /api/sweets/:id/restock - Restock sweet (admin only)
export async function POST(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    // Check admin authorization
    const authResult = await requireAdmin(request)
    if (!authResult.authorized) {
      return NextResponse.json({ success: false, error: "Admin access required" }, { status: 403 })
    }

    const { id } = await params
    const body = await request.json()
    const { quantity } = body

    // Validation
    if (!quantity || quantity <= 0) {
      return NextResponse.json({ success: false, error: "Quantity must be positive" }, { status: 400 })
    }

    // Get current sweet
    const sweet = await db.findSweetById(id)
    if (!sweet) {
      return NextResponse.json({ success: false, error: "Sweet not found" }, { status: 404 })
    }

    // Update quantity
    const updatedSweet = await db.updateSweet(id, {
      quantity: sweet.quantity + quantity,
    })

    return NextResponse.json({
      success: true,
      sweet: updatedSweet,
      message: `Successfully restocked ${quantity} ${sweet.name}`,
    })
  } catch (error) {
    console.error("[v0] Error restocking sweet:", error)
    return NextResponse.json({ success: false, error: "Failed to restock sweet" }, { status: 500 })
  }
}
