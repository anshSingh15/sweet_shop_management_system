// Get, update, and delete individual sweet

import { type NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db/mock-db"
import { requireAdmin } from "@/lib/middleware/auth"

// GET /api/sweets/:id - Get sweet by ID (public)
export async function GET(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const sweet = await db.findSweetById(id)

    if (!sweet) {
      return NextResponse.json({ success: false, error: "Sweet not found" }, { status: 404 })
    }

    return NextResponse.json({
      success: true,
      sweet,
    })
  } catch (error) {
    console.error("[v0] Error fetching sweet:", error)
    return NextResponse.json({ success: false, error: "Failed to fetch sweet" }, { status: 500 })
  }
}

// PUT /api/sweets/:id - Update sweet (admin only)
export async function PUT(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    // Check admin authorization
    const authResult = await requireAdmin(request)
    if (!authResult.authorized) {
      return NextResponse.json({ success: false, error: "Admin access required" }, { status: 403 })
    }

    const { id } = await params
    const body = await request.json()

    // Validate price and quantity if provided
    if (body.price !== undefined && body.price < 0) {
      return NextResponse.json({ success: false, error: "Price must be non-negative" }, { status: 400 })
    }
    if (body.quantity !== undefined && body.quantity < 0) {
      return NextResponse.json({ success: false, error: "Quantity must be non-negative" }, { status: 400 })
    }

    // Update sweet
    const sweet = await db.updateSweet(id, body)

    if (!sweet) {
      return NextResponse.json({ success: false, error: "Sweet not found" }, { status: 404 })
    }

    return NextResponse.json({
      success: true,
      sweet,
    })
  } catch (error) {
    console.error("[v0] Error updating sweet:", error)
    return NextResponse.json({ success: false, error: "Failed to update sweet" }, { status: 500 })
  }
}

// DELETE /api/sweets/:id - Delete sweet (admin only)
export async function DELETE(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    // Check admin authorization
    const authResult = await requireAdmin(request)
    if (!authResult.authorized) {
      return NextResponse.json({ success: false, error: "Admin access required" }, { status: 403 })
    }

    const { id } = await params
    const deleted = await db.deleteSweet(id)

    if (!deleted) {
      return NextResponse.json({ success: false, error: "Sweet not found" }, { status: 404 })
    }

    return NextResponse.json({
      success: true,
      message: "Sweet deleted successfully",
    })
  } catch (error) {
    console.error("[v0] Error deleting sweet:", error)
    return NextResponse.json({ success: false, error: "Failed to delete sweet" }, { status: 500 })
  }
}
