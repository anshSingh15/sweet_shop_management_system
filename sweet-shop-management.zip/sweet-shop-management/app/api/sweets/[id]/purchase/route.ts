// Purchase sweet (decreases quantity)

import { type NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db/mock-db"
import { requireAuth } from "@/lib/middleware/auth"

// POST /api/sweets/:id/purchase - Purchase sweet (requires auth)
export async function POST(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    // Check authentication
    const authResult = await requireAuth(request)
    if (!authResult.authorized || !authResult.user) {
      return NextResponse.json({ success: false, error: "Authentication required" }, { status: 401 })
    }

    const { id } = await params
    const body = await request.json()
    const { quantity } = body

    // Validation
    if (!quantity || quantity <= 0) {
      return NextResponse.json({ success: false, error: "Quantity must be positive" }, { status: 400 })
    }

    // Get current sweet
    const sweet = await db.findSweetById(id)
    if (!sweet) {
      return NextResponse.json({ success: false, error: "Sweet not found" }, { status: 404 })
    }

    // Check stock availability
    if (sweet.quantity < quantity) {
      return NextResponse.json(
        { success: false, error: "Insufficient stock", available: sweet.quantity },
        { status: 400 },
      )
    }

    // Update quantity
    const updatedSweet = await db.updateSweet(id, {
      quantity: sweet.quantity - quantity,
    })

    // Record purchase
    await db.createPurchase({
      userId: authResult.user.userId,
      sweetId: id,
      quantity,
      totalPrice: sweet.price * quantity,
    })

    return NextResponse.json({
      success: true,
      sweet: updatedSweet,
      message: `Successfully purchased ${quantity} ${sweet.name}`,
    })
  } catch (error) {
    console.error("[v0] Error processing purchase:", error)
    return NextResponse.json({ success: false, error: "Failed to process purchase" }, { status: 500 })
  }
}
