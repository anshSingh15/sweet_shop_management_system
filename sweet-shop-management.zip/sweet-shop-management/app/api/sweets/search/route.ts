// Search sweets by name, category, or price range

import { type NextRequest, NextResponse } from "next/server"
import { db } from "@/lib/db/mock-db"

// GET /api/sweets/search - Search sweets (public)
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const name = searchParams.get("name") || undefined
    const category = searchParams.get("category") || undefined
    const minPrice = searchParams.get("minPrice") ? Number(searchParams.get("minPrice")) : undefined
    const maxPrice = searchParams.get("maxPrice") ? Number(searchParams.get("maxPrice")) : undefined

    const sweets = await db.searchSweets({
      name,
      category,
      minPrice,
      maxPrice,
    })

    return NextResponse.json({
      success: true,
      sweets,
      count: sweets.length,
    })
  } catch (error) {
    console.error("[v0] Error searching sweets:", error)
    return NextResponse.json({ success: false, error: "Failed to search sweets" }, { status: 500 })
  }
}
