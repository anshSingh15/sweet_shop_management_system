"use client"

import { useEffect, useState } from "react"
import { useAuth } from "@/lib/hooks/use-auth"
import { apiClient } from "@/lib/api/client"
import { LoginForm } from "@/components/auth/login-form"
import { RegisterForm } from "@/components/auth/register-form"
import { SweetCard } from "@/components/sweet-card"
import { SweetFormDialog } from "@/components/admin/sweet-form-dialog"
import { RestockDialog } from "@/components/admin/restock-dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Candy, LogOut, Plus, Search } from "lucide-react"

export default function Home() {
  const { user, isAuthenticated, logout } = useAuth()
  const [showAuth, setShowAuth] = useState(false)
  const [authMode, setAuthMode] = useState<"login" | "register">("login")
  const [sweets, setSweets] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState("")
  const [categoryFilter, setCategoryFilter] = useState<string>("all")
  const [showSweetForm, setShowSweetForm] = useState(false)
  const [showRestockDialog, setShowRestockDialog] = useState(false)
  const [editingSweet, setEditingSweet] = useState<any>(null)
  const [restockingSweet, setRestockingSweet] = useState<any>(null)

  const isAdmin = user?.role === "admin"

  useEffect(() => {
    if (isAuthenticated && user) {
      apiClient.setToken(useAuth.getState().token || "")
    }
    loadSweets()
  }, [isAuthenticated, user])

  const loadSweets = async () => {
    try {
      setLoading(true)
      const response = await apiClient.getSweets()
      setSweets(response.sweets)
    } catch (err) {
      console.error("Failed to load sweets:", err)
    } finally {
      setLoading(false)
    }
  }

  const handleLogout = () => {
    apiClient.clearToken()
    logout()
  }

  const handleDeleteSweet = async (id: string) => {
    if (!confirm("Are you sure you want to delete this sweet?")) return

    try {
      await apiClient.deleteSweet(id)
      loadSweets()
    } catch (err: any) {
      alert(err.message || "Failed to delete sweet")
    }
  }

  const handleEditSweet = (sweet: any) => {
    setEditingSweet(sweet)
    setShowSweetForm(true)
  }

  const handleRestockSweet = (sweet: any) => {
    setRestockingSweet(sweet)
    setShowRestockDialog(true)
  }

  const categories = ["all", ...new Set(sweets.map((s) => s.category.toLowerCase()))]
  const filteredSweets = sweets.filter((sweet) => {
    const matchesSearch = sweet.name.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesCategory = categoryFilter === "all" || sweet.category.toLowerCase() === categoryFilter
    return matchesSearch && matchesCategory
  })

  if (!isAuthenticated && showAuth) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        {authMode === "login" ? (
          <LoginForm
            onSuccess={() => {
              setShowAuth(false)
              loadSweets()
            }}
            onSwitchToRegister={() => setAuthMode("register")}
          />
        ) : (
          <RegisterForm
            onSuccess={() => {
              setShowAuth(false)
              loadSweets()
            }}
            onSwitchToLogin={() => setAuthMode("login")}
          />
        )}
      </div>
    )
  }

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="border-b bg-card/50 backdrop-blur-sm sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="bg-primary text-primary-foreground p-2 rounded-xl">
                <Candy className="h-6 w-6" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-balance">Sweet Shop</h1>
                <p className="text-sm text-muted-foreground">Delicious treats for everyone</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              {isAuthenticated ? (
                <>
                  <div className="text-right hidden sm:block">
                    <p className="text-sm font-medium">{user?.name}</p>
                    <p className="text-xs text-muted-foreground capitalize">{user?.role}</p>
                  </div>
                  <Button variant="outline" onClick={handleLogout}>
                    <LogOut className="h-4 w-4 mr-2" />
                    Logout
                  </Button>
                </>
              ) : (
                <>
                  <Button
                    variant="outline"
                    onClick={() => {
                      setAuthMode("login")
                      setShowAuth(true)
                    }}
                  >
                    Sign In
                  </Button>
                  <Button
                    onClick={() => {
                      setAuthMode("register")
                      setShowAuth(true)
                    }}
                  >
                    Register
                  </Button>
                </>
              )}
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {/* Search and Filters */}
        <div className="mb-8 space-y-4">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search sweets..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={categoryFilter} onValueChange={setCategoryFilter}>
              <SelectTrigger className="w-full sm:w-48">
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                {categories.map((cat) => (
                  <SelectItem key={cat} value={cat}>
                    {cat === "all" ? "All Categories" : cat.charAt(0).toUpperCase() + cat.slice(1)}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {isAdmin && (
              <Button
                onClick={() => {
                  setEditingSweet(null)
                  setShowSweetForm(true)
                }}
              >
                <Plus className="h-4 w-4 mr-2" />
                Add Sweet
              </Button>
            )}
          </div>
        </div>

        {/* Sweet Grid */}
        {loading ? (
          <div className="text-center py-12">
            <p className="text-muted-foreground">Loading sweets...</p>
          </div>
        ) : filteredSweets.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-muted-foreground">No sweets found</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredSweets.map((sweet) => (
              <SweetCard
                key={sweet.id}
                sweet={sweet}
                onUpdate={loadSweets}
                onEdit={handleEditSweet}
                onDelete={handleDeleteSweet}
              />
            ))}
          </div>
        )}
      </main>

      {/* Dialogs */}
      <SweetFormDialog
        open={showSweetForm}
        onClose={() => {
          setShowSweetForm(false)
          setEditingSweet(null)
        }}
        onSuccess={loadSweets}
        sweet={editingSweet}
      />
      <RestockDialog
        open={showRestockDialog}
        onClose={() => {
          setShowRestockDialog(false)
          setRestockingSweet(null)
        }}
        onSuccess={loadSweets}
        sweet={restockingSweet}
      />
    </div>
  )
}
