// JWT utility functions for token-based authentication

import { SignJWT, jwtVerify } from "jose"

const JWT_SECRET =
  process.env.NEXTAUTH_SECRET || process.env.JWT_SECRET || "sweet-shop-secret-key-change-in-production-use-env-var"
const secret = new TextEncoder().encode(JWT_SECRET)

export interface JWTPayload {
  userId: string
  email: string
  role: "user" | "admin"
}

export async function signToken(payload: JWTPayload): Promise<string> {
  const token = await new SignJWT({ ...payload })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime("24h")
    .sign(secret)

  return token
}

export async function verifyToken(token: string): Promise<JWTPayload | null> {
  try {
    const { payload } = await jwtVerify(token, secret)
    return payload as JWTPayload
  } catch (error) {
    return null
  }
}
