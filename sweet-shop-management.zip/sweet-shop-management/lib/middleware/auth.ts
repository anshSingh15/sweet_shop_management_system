// Authentication middleware for protected routes

import { type NextRequest, NextResponse } from "next/server"
import { verifyToken, type JWTPayload } from "@/lib/utils/jwt"

export interface AuthRequest extends NextRequest {
  user?: JWTPayload
}

export async function requireAuth(request: NextRequest): Promise<{ authorized: boolean; user?: JWTPayload }> {
  const authHeader = request.headers.get("authorization")

  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return { authorized: false }
  }

  const token = authHeader.substring(7)
  const payload = await verifyToken(token)

  if (!payload) {
    return { authorized: false }
  }

  return { authorized: true, user: payload }
}

export async function requireAdmin(request: NextRequest): Promise<{ authorized: boolean; user?: JWTPayload }> {
  const authResult = await requireAuth(request)

  if (!authResult.authorized || !authResult.user) {
    return { authorized: false }
  }

  if (authResult.user.role !== "admin") {
    return { authorized: false }
  }

  return authResult
}

export function unauthorizedResponse(message = "Unauthorized") {
  return NextResponse.json({ success: false, error: message }, { status: 401 })
}

export function forbiddenResponse(message = "Forbidden - Admin access required") {
  return NextResponse.json({ success: false, error: message }, { status: 403 })
}
