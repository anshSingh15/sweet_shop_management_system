// Database schema definitions for the Sweet Shop Management System

export interface User {
  id: string
  email: string
  password: string // Hashed password
  name: string
  role: "user" | "admin"
  createdAt: Date
  updatedAt: Date
}

export interface Sweet {
  id: string
  name: string
  category: string
  price: number
  quantity: number
  description?: string
  imageUrl?: string
  createdAt: Date
  updatedAt: Date
}

export interface PurchaseHistory {
  id: string
  userId: string
  sweetId: string
  quantity: number
  totalPrice: number
  createdAt: Date
}

// Database interface for dependency injection
export interface Database {
  // User operations
  createUser(user: Omit<User, "id" | "createdAt" | "updatedAt">): Promise<User>
  findUserByEmail(email: string): Promise<User | null>
  findUserById(id: string): Promise<User | null>

  // Sweet operations
  createSweet(sweet: Omit<Sweet, "id" | "createdAt" | "updatedAt">): Promise<Sweet>
  findAllSweets(): Promise<Sweet[]>
  findSweetById(id: string): Promise<Sweet | null>
  updateSweet(id: string, updates: Partial<Sweet>): Promise<Sweet | null>
  deleteSweet(id: string): Promise<boolean>
  searchSweets(params: { name?: string; category?: string; minPrice?: number; maxPrice?: number }): Promise<Sweet[]>

  // Purchase operations
  createPurchase(purchase: Omit<PurchaseHistory, "id" | "createdAt">): Promise<PurchaseHistory>
  findPurchasesByUserId(userId: string): Promise<PurchaseHistory[]>
}
