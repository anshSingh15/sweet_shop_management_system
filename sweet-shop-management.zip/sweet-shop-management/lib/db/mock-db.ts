// Mock database implementation for development
// Replace with actual database implementation in production

import type { Database, User, Sweet, PurchaseHistory } from "./schema"
import { randomUUID } from "crypto"

class MockDatabase implements Database {
  private users: User[] = []
  private sweets: Sweet[] = []
  private purchases: PurchaseHistory[] = []

  // User operations
  async createUser(userData: Omit<User, "id" | "createdAt" | "updatedAt">): Promise<User> {
    const user: User = {
      ...userData,
      id: randomUUID(),
      createdAt: new Date(),
      updatedAt: new Date(),
    }
    this.users.push(user)
    return user
  }

  async findUserByEmail(email: string): Promise<User | null> {
    return this.users.find((u) => u.email === email) || null
  }

  async findUserById(id: string): Promise<User | null> {
    return this.users.find((u) => u.id === id) || null
  }

  // Sweet operations
  async createSweet(sweetData: Omit<Sweet, "id" | "createdAt" | "updatedAt">): Promise<Sweet> {
    const sweet: Sweet = {
      ...sweetData,
      id: randomUUID(),
      createdAt: new Date(),
      updatedAt: new Date(),
    }
    this.sweets.push(sweet)
    return sweet
  }

  async findAllSweets(): Promise<Sweet[]> {
    return [...this.sweets]
  }

  async findSweetById(id: string): Promise<Sweet | null> {
    return this.sweets.find((s) => s.id === id) || null
  }

  async updateSweet(id: string, updates: Partial<Sweet>): Promise<Sweet | null> {
    const index = this.sweets.findIndex((s) => s.id === id)
    if (index === -1) return null

    this.sweets[index] = {
      ...this.sweets[index],
      ...updates,
      id: this.sweets[index].id, // Preserve ID
      createdAt: this.sweets[index].createdAt, // Preserve creation date
      updatedAt: new Date(),
    }
    return this.sweets[index]
  }

  async deleteSweet(id: string): Promise<boolean> {
    const index = this.sweets.findIndex((s) => s.id === id)
    if (index === -1) return false
    this.sweets.splice(index, 1)
    return true
  }

  async searchSweets(params: { name?: string; category?: string; minPrice?: number; maxPrice?: number }): Promise<
    Sweet[]
  > {
    return this.sweets.filter((sweet) => {
      if (params.name && !sweet.name.toLowerCase().includes(params.name.toLowerCase())) {
        return false
      }
      if (params.category && sweet.category.toLowerCase() !== params.category.toLowerCase()) {
        return false
      }
      if (params.minPrice !== undefined && sweet.price < params.minPrice) {
        return false
      }
      if (params.maxPrice !== undefined && sweet.price > params.maxPrice) {
        return false
      }
      return true
    })
  }

  // Purchase operations
  async createPurchase(purchaseData: Omit<PurchaseHistory, "id" | "createdAt">): Promise<PurchaseHistory> {
    const purchase: PurchaseHistory = {
      ...purchaseData,
      id: randomUUID(),
      createdAt: new Date(),
    }
    this.purchases.push(purchase)
    return purchase
  }

  async findPurchasesByUserId(userId: string): Promise<PurchaseHistory[]> {
    return this.purchases.filter((p) => p.userId === userId)
  }

  // Helper method to seed data (for testing)
  async seed(): Promise<void> {
    // Clear existing data
    this.users = []
    this.sweets = []
    this.purchases = []

    // Add admin user (password: admin123 - will be hashed in auth service)
    await this.createUser({
      email: "admin@sweetshop.com",
      password: "$2b$10$rKvVVH8TQhF0cLwQGKqGCOxK4K1qN8pJ4QyQh5vN8nYy5xD7xJ7Ky",
      name: "Admin User",
      role: "admin",
    })

    // Add sample Indian sweets
    const sampleSweets = [
      {
        name: "Gulab Jamun",
        category: "Milk-Based",
        price: 120,
        quantity: 80,
        description: "Soft milk-solid balls deep-fried and soaked in rose-flavored sugar syrup",
        imageUrl: "/gulab-jamun-indian-sweet.jpg",
      },
      {
        name: "Rasgulla",
        category: "Milk-Based",
        price: 100,
        quantity: 100,
        description: "Spongy cottage cheese balls soaked in light sugar syrup",
        imageUrl: "/rasgulla-indian-sweet.jpg",
      },
      {
        name: "Jalebi",
        category: "Fried",
        price: 80,
        quantity: 120,
        description: "Crispy pretzel-shaped sweet soaked in saffron-flavored sugar syrup",
        imageUrl: "/jalebi-indian-sweet.jpg",
      },
      {
        name: "Barfi",
        category: "Milk-Based",
        price: 150,
        quantity: 60,
        description: "Dense milk-based sweet with cardamom and pistachios",
        imageUrl: "/barfi-indian-sweet.jpg",
      },
      {
        name: "Ladoo",
        category: "Flour-Based",
        price: 90,
        quantity: 150,
        description: "Round balls made from flour, ghee, and sugar with aromatic spices",
        imageUrl: "/ladoo-indian-sweet.jpg",
      },
      {
        name: "Rasmalai",
        category: "Milk-Based",
        price: 180,
        quantity: 50,
        description: "Soft paneer patties in creamy, saffron-flavored milk",
        imageUrl: "/rasmalai-indian-sweet.jpg",
      },
      {
        name: "Mysore Pak",
        category: "Flour-Based",
        price: 130,
        quantity: 70,
        description: "Rich, buttery sweet made with gram flour and pure ghee",
        imageUrl: "/mysore-pak-indian-sweet.jpg",
      },
      {
        name: "Kaju Katli",
        category: "Dry Fruit",
        price: 250,
        quantity: 40,
        description: "Premium cashew fudge with edible silver leaf",
        imageUrl: "/kaju-katli-indian-sweet.jpg",
      },
    ]

    for (const sweet of sampleSweets) {
      await this.createSweet(sweet)
    }
  }
}

// Export singleton instance
export const db = new MockDatabase()

// Initialize with seed data
db.seed()
