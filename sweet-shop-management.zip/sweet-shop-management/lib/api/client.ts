// API client for frontend

const API_BASE = "/api"

export interface ApiResponse<T> {
  success: boolean
  data?: T
  error?: string
}

class ApiClient {
  private token: string | null = null

  constructor() {
    // Load token from localStorage on client
    if (typeof window !== "undefined") {
      this.token = localStorage.getItem("auth_token")
    }
  }

  setToken(token: string) {
    this.token = token
    if (typeof window !== "undefined") {
      localStorage.setItem("auth_token", token)
    }
  }

  clearToken() {
    this.token = null
    if (typeof window !== "undefined") {
      localStorage.removeItem("auth_token")
    }
  }

  getToken() {
    return this.token
  }

  private async request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
    const headers: HeadersInit = {
      "Content-Type": "application/json",
      ...options.headers,
    }

    if (this.token) {
      headers["Authorization"] = `Bearer ${this.token}`
    }

    const response = await fetch(`${API_BASE}${endpoint}`, {
      ...options,
      headers,
    })

    const data = await response.json()

    if (!data.success) {
      throw new Error(data.error || "Request failed")
    }

    return data
  }

  // Auth endpoints
  async register(email: string, password: string, name: string) {
    return this.request<{ user: any; token: string }>("/auth/register", {
      method: "POST",
      body: JSON.stringify({ email, password, name }),
    })
  }

  async login(email: string, password: string) {
    return this.request<{ user: any; token: string }>("/auth/login", {
      method: "POST",
      body: JSON.stringify({ email, password }),
    })
  }

  // Sweet endpoints
  async getSweets() {
    return this.request<{ sweets: any[] }>("/sweets", { method: "GET" })
  }

  async searchSweets(params: { name?: string; category?: string; minPrice?: number; maxPrice?: number }) {
    const query = new URLSearchParams()
    if (params.name) query.append("name", params.name)
    if (params.category) query.append("category", params.category)
    if (params.minPrice !== undefined) query.append("minPrice", params.minPrice.toString())
    if (params.maxPrice !== undefined) query.append("maxPrice", params.maxPrice.toString())

    return this.request<{ sweets: any[] }>(`/sweets/search?${query}`, { method: "GET" })
  }

  async createSweet(sweet: any) {
    return this.request<{ sweet: any }>("/sweets", {
      method: "POST",
      body: JSON.stringify(sweet),
    })
  }

  async updateSweet(id: string, updates: any) {
    return this.request<{ sweet: any }>(`/sweets/${id}`, {
      method: "PUT",
      body: JSON.stringify(updates),
    })
  }

  async deleteSweet(id: string) {
    return this.request<{ message: string }>(`/sweets/${id}`, { method: "DELETE" })
  }

  async purchaseSweet(id: string, quantity: number) {
    return this.request<{ sweet: any; message: string }>(`/sweets/${id}/purchase`, {
      method: "POST",
      body: JSON.stringify({ quantity }),
    })
  }

  async restockSweet(id: string, quantity: number) {
    return this.request<{ sweet: any; message: string }>(`/sweets/${id}/restock`, {
      method: "POST",
      body: JSON.stringify({ quantity }),
    })
  }
}

export const apiClient = new ApiClient()
