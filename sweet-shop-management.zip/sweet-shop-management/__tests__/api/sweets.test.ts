// TDD: Tests for sweet management endpoints

import { GET as listHandler, POST as createHandler } from "@/app/api/sweets/route"
import { PUT as updateHandler, DELETE as deleteHandler } from "@/app/api/sweets/[id]/route"
import { POST as purchaseHandler } from "@/app/api/sweets/[id]/purchase/route"
import { POST as restockHandler } from "@/app/api/sweets/[id]/restock/route"
import { GET as searchHandler } from "@/app/api/sweets/search/route"
import { db } from "@/lib/db/mock-db"
import { signToken } from "@/lib/utils/jwt"
import { NextRequest } from "next/server"

function createMockRequest(url: string, method: string, body?: any, token?: string): NextRequest {
  const headers: HeadersInit = { "Content-Type": "application/json" }
  if (token) {
    headers["Authorization"] = `Bearer ${token}`
  }

  return new NextRequest(url, {
    method,
    headers,
    body: body ? JSON.stringify(body) : undefined,
  })
}

describe("Sweets API - List and Create", () => {
  let userToken: string
  let adminToken: string

  beforeEach(async () => {
    await db.seed()
    userToken = await signToken({ userId: "user-1", email: "user@test.com", role: "user" })
    adminToken = await signToken({ userId: "admin-1", email: "admin@test.com", role: "admin" })
  })

  it("should list all sweets without authentication", async () => {
    const request = createMockRequest("http://localhost:3000/api/sweets", "GET")
    const response = await listHandler(request)
    const data = await response.json()

    expect(response.status).toBe(200)
    expect(data.success).toBe(true)
    expect(Array.isArray(data.sweets)).toBe(true)
    expect(data.sweets.length).toBeGreaterThan(0)
  })

  it("should create a sweet with admin token", async () => {
    const request = createMockRequest(
      "http://localhost:3000/api/sweets",
      "POST",
      {
        name: "New Candy",
        category: "Chocolate",
        price: 15.99,
        quantity: 50,
        description: "Test candy",
      },
      adminToken,
    )

    const response = await createHandler(request)
    const data = await response.json()

    expect(response.status).toBe(201)
    expect(data.success).toBe(true)
    expect(data.sweet.name).toBe("New Candy")
  })

  it("should reject sweet creation without admin token", async () => {
    const request = createMockRequest(
      "http://localhost:3000/api/sweets",
      "POST",
      {
        name: "New Candy",
        category: "Chocolate",
        price: 15.99,
        quantity: 50,
      },
      userToken,
    )

    const response = await createHandler(request)
    expect(response.status).toBe(403)
  })
})

describe("Sweets API - Update and Delete", () => {
  let adminToken: string
  let sweetId: string

  beforeEach(async () => {
    await db.seed()
    adminToken = await signToken({ userId: "admin-1", email: "admin@test.com", role: "admin" })
    const sweets = await db.findAllSweets()
    sweetId = sweets[0].id
  })

  it("should update a sweet with admin token", async () => {
    const request = createMockRequest(
      `http://localhost:3000/api/sweets/${sweetId}`,
      "PUT",
      {
        price: 99.99,
        quantity: 200,
      },
      adminToken,
    )

    const response = await updateHandler(request, { params: Promise.resolve({ id: sweetId }) })
    const data = await response.json()

    expect(response.status).toBe(200)
    expect(data.success).toBe(true)
    expect(data.sweet.price).toBe(99.99)
  })

  it("should delete a sweet with admin token", async () => {
    const request = createMockRequest(`http://localhost:3000/api/sweets/${sweetId}`, "DELETE", undefined, adminToken)

    const response = await deleteHandler(request, { params: Promise.resolve({ id: sweetId }) })
    const data = await response.json()

    expect(response.status).toBe(200)
    expect(data.success).toBe(true)
  })
})

describe("Sweets API - Search", () => {
  beforeEach(async () => {
    await db.seed()
  })

  it("should search sweets by name", async () => {
    const request = createMockRequest("http://localhost:3000/api/sweets/search?name=chocolate", "GET")
    const response = await searchHandler(request)
    const data = await response.json()

    expect(response.status).toBe(200)
    expect(data.success).toBe(true)
    expect(data.sweets.every((s: any) => s.name.toLowerCase().includes("chocolate"))).toBe(true)
  })

  it("should search sweets by category", async () => {
    const request = createMockRequest("http://localhost:3000/api/sweets/search?category=gummy", "GET")
    const response = await searchHandler(request)
    const data = await response.json()

    expect(response.status).toBe(200)
    expect(data.sweets.every((s: any) => s.category.toLowerCase() === "gummy")).toBe(true)
  })

  it("should search sweets by price range", async () => {
    const request = createMockRequest("http://localhost:3000/api/sweets/search?minPrice=5&maxPrice=10", "GET")
    const response = await searchHandler(request)
    const data = await response.json()

    expect(response.status).toBe(200)
    expect(data.sweets.every((s: any) => s.price >= 5 && s.price <= 10)).toBe(true)
  })
})

describe("Sweets API - Purchase and Restock", () => {
  let userToken: string
  let adminToken: string
  let sweetId: string

  beforeEach(async () => {
    await db.seed()
    userToken = await signToken({ userId: "user-1", email: "user@test.com", role: "user" })
    adminToken = await signToken({ userId: "admin-1", email: "admin@test.com", role: "admin" })
    const sweets = await db.findAllSweets()
    sweetId = sweets[0].id
  })

  it("should purchase a sweet and decrease quantity", async () => {
    const sweet = await db.findSweetById(sweetId)
    const initialQuantity = sweet!.quantity

    const request = createMockRequest(
      `http://localhost:3000/api/sweets/${sweetId}/purchase`,
      "POST",
      { quantity: 2 },
      userToken,
    )

    const response = await purchaseHandler(request, { params: Promise.resolve({ id: sweetId }) })
    const data = await response.json()

    expect(response.status).toBe(200)
    expect(data.success).toBe(true)
    expect(data.sweet.quantity).toBe(initialQuantity - 2)
  })

  it("should reject purchase when quantity exceeds stock", async () => {
    const request = createMockRequest(
      `http://localhost:3000/api/sweets/${sweetId}/purchase`,
      "POST",
      { quantity: 10000 },
      userToken,
    )

    const response = await purchaseHandler(request, { params: Promise.resolve({ id: sweetId }) })
    expect(response.status).toBe(400)
  })

  it("should restock a sweet with admin token", async () => {
    const sweet = await db.findSweetById(sweetId)
    const initialQuantity = sweet!.quantity

    const request = createMockRequest(
      `http://localhost:3000/api/sweets/${sweetId}/restock`,
      "POST",
      { quantity: 50 },
      adminToken,
    )

    const response = await restockHandler(request, { params: Promise.resolve({ id: sweetId }) })
    const data = await response.json()

    expect(response.status).toBe(200)
    expect(data.success).toBe(true)
    expect(data.sweet.quantity).toBe(initialQuantity + 50)
  })

  it("should reject restock without admin token", async () => {
    const request = createMockRequest(
      `http://localhost:3000/api/sweets/${sweetId}/restock`,
      "POST",
      { quantity: 50 },
      userToken,
    )

    const response = await restockHandler(request, { params: Promise.resolve({ id: sweetId }) })
    expect(response.status).toBe(403)
  })
})
