// TDD: Write tests first for authentication endpoints

import { POST as registerHandler } from "@/app/api/auth/register/route"
import { POST as loginHandler } from "@/app/api/auth/login/route"
import { db } from "@/lib/db/mock-db"
import { hashPassword } from "@/lib/utils/password"
import { NextRequest } from "next/server"

// Helper to create mock request
function createMockRequest(body: any): NextRequest {
  return new NextRequest("http://localhost:3000/api/test", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  })
}

describe("Auth API - Registration", () => {
  beforeEach(async () => {
    // Reset database before each test
    await db.seed()
  })

  it("should register a new user successfully", async () => {
    const request = createMockRequest({
      email: "test@example.com",
      password: "password123",
      name: "Test User",
    })

    const response = await registerHandler(request)
    const data = await response.json()

    expect(response.status).toBe(201)
    expect(data.success).toBe(true)
    expect(data.user.email).toBe("test@example.com")
    expect(data.user.name).toBe("Test User")
    expect(data.token).toBeDefined()
    expect(data.user.password).toBeUndefined() // Password should not be returned
  })

  it("should reject registration with existing email", async () => {
    const request = createMockRequest({
      email: "admin@sweetshop.com", // Already exists in seed data
      password: "password123",
      name: "Another User",
    })

    const response = await registerHandler(request)
    const data = await response.json()

    expect(response.status).toBe(400)
    expect(data.success).toBe(false)
    expect(data.error).toContain("already exists")
  })

  it("should reject registration with missing fields", async () => {
    const request = createMockRequest({
      email: "test@example.com",
      // Missing password and name
    })

    const response = await registerHandler(request)
    const data = await response.json()

    expect(response.status).toBe(400)
    expect(data.success).toBe(false)
  })

  it("should reject registration with invalid email format", async () => {
    const request = createMockRequest({
      email: "invalid-email",
      password: "password123",
      name: "Test User",
    })

    const response = await registerHandler(request)
    const data = await response.json()

    expect(response.status).toBe(400)
    expect(data.success).toBe(false)
  })
})

describe("Auth API - Login", () => {
  beforeEach(async () => {
    await db.seed()
    // Create a test user
    const hashedPassword = await hashPassword("password123")
    await db.createUser({
      email: "testuser@example.com",
      password: hashedPassword,
      name: "Test User",
      role: "user",
    })
  })

  it("should login with correct credentials", async () => {
    const request = createMockRequest({
      email: "testuser@example.com",
      password: "password123",
    })

    const response = await loginHandler(request)
    const data = await response.json()

    expect(response.status).toBe(200)
    expect(data.success).toBe(true)
    expect(data.user.email).toBe("testuser@example.com")
    expect(data.token).toBeDefined()
    expect(data.user.password).toBeUndefined()
  })

  it("should reject login with incorrect password", async () => {
    const request = createMockRequest({
      email: "testuser@example.com",
      password: "wrongpassword",
    })

    const response = await loginHandler(request)
    const data = await response.json()

    expect(response.status).toBe(401)
    expect(data.success).toBe(false)
    expect(data.error).toContain("Invalid")
  })

  it("should reject login with non-existent email", async () => {
    const request = createMockRequest({
      email: "nonexistent@example.com",
      password: "password123",
    })

    const response = await loginHandler(request)
    const data = await response.json()

    expect(response.status).toBe(401)
    expect(data.success).toBe(false)
  })

  it("should reject login with missing credentials", async () => {
    const request = createMockRequest({
      email: "testuser@example.com",
      // Missing password
    })

    const response = await loginHandler(request)
    const data = await response.json()

    expect(response.status).toBe(400)
    expect(data.success).toBe(false)
  })
})
