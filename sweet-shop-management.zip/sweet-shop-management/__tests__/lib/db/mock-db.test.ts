// Unit tests for mock database implementation

import { db } from "@/lib/db/mock-db"
import { hashPassword } from "@/lib/utils/password"

describe("MockDatabase - User Operations", () => {
  beforeEach(async () => {
    await db.seed()
  })

  describe("createUser", () => {
    it("should create a user with all fields", async () => {
      const userData = {
        email: "newuser@test.com",
        password: await hashPassword("password123"),
        name: "New User",
        role: "user" as const,
      }

      const user = await db.createUser(userData)

      expect(user.id).toBeDefined()
      expect(user.email).toBe(userData.email)
      expect(user.name).toBe(userData.name)
      expect(user.role).toBe("user")
      expect(user.createdAt).toBeInstanceOf(Date)
      expect(user.updatedAt).toBeInstanceOf(Date)
    })

    it("should generate unique IDs for different users", async () => {
      const user1 = await db.createUser({
        email: "user1@test.com",
        password: "hash1",
        name: "User 1",
        role: "user",
      })

      const user2 = await db.createUser({
        email: "user2@test.com",
        password: "hash2",
        name: "User 2",
        role: "user",
      })

      expect(user1.id).not.toBe(user2.id)
    })
  })

  describe("findUserByEmail", () => {
    it("should find existing user by email", async () => {
      const user = await db.findUserByEmail("admin@sweetshop.com")
      expect(user).not.toBeNull()
      expect(user?.email).toBe("admin@sweetshop.com")
      expect(user?.role).toBe("admin")
    })

    it("should return null for non-existent email", async () => {
      const user = await db.findUserByEmail("nonexistent@test.com")
      expect(user).toBeNull()
    })

    it("should be case-sensitive", async () => {
      const user = await db.findUserByEmail("ADMIN@SWEETSHOP.COM")
      expect(user).toBeNull()
    })
  })

  describe("findUserById", () => {
    it("should find user by ID", async () => {
      const createdUser = await db.createUser({
        email: "findme@test.com",
        password: "hash",
        name: "Find Me",
        role: "user",
      })

      const foundUser = await db.findUserById(createdUser.id)
      expect(foundUser).not.toBeNull()
      expect(foundUser?.id).toBe(createdUser.id)
    })

    it("should return null for non-existent ID", async () => {
      const user = await db.findUserById("non-existent-id")
      expect(user).toBeNull()
    })
  })
})

describe("MockDatabase - Sweet Operations", () => {
  beforeEach(async () => {
    await db.seed()
  })

  describe("createSweet", () => {
    it("should create a sweet with all required fields", async () => {
      const sweetData = {
        name: "Test Candy",
        category: "Test Category",
        price: 9.99,
        quantity: 100,
        description: "A test candy",
      }

      const sweet = await db.createSweet(sweetData)

      expect(sweet.id).toBeDefined()
      expect(sweet.name).toBe(sweetData.name)
      expect(sweet.price).toBe(sweetData.price)
      expect(sweet.quantity).toBe(sweetData.quantity)
      expect(sweet.createdAt).toBeInstanceOf(Date)
    })
  })

  describe("findAllSweets", () => {
    it("should return all sweets", async () => {
      const sweets = await db.findAllSweets()
      expect(sweets.length).toBeGreaterThan(0)
      expect(Array.isArray(sweets)).toBe(true)
    })

    it("should return a copy of sweets array", async () => {
      const sweets1 = await db.findAllSweets()
      const sweets2 = await db.findAllSweets()
      expect(sweets1).not.toBe(sweets2) // Different array instances
      expect(sweets1).toEqual(sweets2) // Same content
    })
  })

  describe("findSweetById", () => {
    it("should find sweet by ID", async () => {
      const allSweets = await db.findAllSweets()
      const firstSweet = allSweets[0]

      const foundSweet = await db.findSweetById(firstSweet.id)
      expect(foundSweet).not.toBeNull()
      expect(foundSweet?.id).toBe(firstSweet.id)
    })

    it("should return null for non-existent ID", async () => {
      const sweet = await db.findSweetById("non-existent-id")
      expect(sweet).toBeNull()
    })
  })

  describe("updateSweet", () => {
    it("should update sweet fields", async () => {
      const allSweets = await db.findAllSweets()
      const sweetToUpdate = allSweets[0]

      const updated = await db.updateSweet(sweetToUpdate.id, {
        price: 99.99,
        quantity: 500,
      })

      expect(updated).not.toBeNull()
      expect(updated?.price).toBe(99.99)
      expect(updated?.quantity).toBe(500)
      expect(updated?.name).toBe(sweetToUpdate.name) // Unchanged field
    })

    it("should return null for non-existent sweet", async () => {
      const updated = await db.updateSweet("non-existent-id", { price: 10 })
      expect(updated).toBeNull()
    })

    it("should preserve ID and creation date", async () => {
      const allSweets = await db.findAllSweets()
      const original = allSweets[0]

      const updated = await db.updateSweet(original.id, { price: 50 })

      expect(updated?.id).toBe(original.id)
      expect(updated?.createdAt).toEqual(original.createdAt)
    })

    it("should update the updatedAt timestamp", async () => {
      const allSweets = await db.findAllSweets()
      const original = allSweets[0]

      await new Promise((resolve) => setTimeout(resolve, 10))

      const updated = await db.updateSweet(original.id, { price: 50 })

      expect(updated?.updatedAt.getTime()).toBeGreaterThan(original.updatedAt.getTime())
    })
  })

  describe("deleteSweet", () => {
    it("should delete existing sweet", async () => {
      const allSweets = await db.findAllSweets()
      const sweetToDelete = allSweets[0]

      const deleted = await db.deleteSweet(sweetToDelete.id)
      expect(deleted).toBe(true)

      const found = await db.findSweetById(sweetToDelete.id)
      expect(found).toBeNull()
    })

    it("should return false for non-existent sweet", async () => {
      const deleted = await db.deleteSweet("non-existent-id")
      expect(deleted).toBe(false)
    })
  })

  describe("searchSweets", () => {
    it("should search by name (case-insensitive)", async () => {
      const results = await db.searchSweets({ name: "chocolate" })
      expect(results.length).toBeGreaterThan(0)
      expect(results.every((s) => s.name.toLowerCase().includes("chocolate"))).toBe(true)
    })

    it("should search by category (case-insensitive)", async () => {
      const results = await db.searchSweets({ category: "gummy" })
      expect(results.length).toBeGreaterThan(0)
      expect(results.every((s) => s.category.toLowerCase() === "gummy")).toBe(true)
    })

    it("should search by minimum price", async () => {
      const results = await db.searchSweets({ minPrice: 10 })
      expect(results.every((s) => s.price >= 10)).toBe(true)
    })

    it("should search by maximum price", async () => {
      const results = await db.searchSweets({ maxPrice: 10 })
      expect(results.every((s) => s.price <= 10)).toBe(true)
    })

    it("should search by price range", async () => {
      const results = await db.searchSweets({ minPrice: 5, maxPrice: 10 })
      expect(results.every((s) => s.price >= 5 && s.price <= 10)).toBe(true)
    })

    it("should combine multiple search criteria", async () => {
      const results = await db.searchSweets({
        category: "chocolate",
        minPrice: 5,
        maxPrice: 15,
      })
      expect(results.every((s) => s.category.toLowerCase() === "chocolate" && s.price >= 5 && s.price <= 15)).toBe(true)
    })

    it("should return empty array when no matches", async () => {
      const results = await db.searchSweets({
        name: "nonexistent-sweet-12345",
      })
      expect(results).toEqual([])
    })
  })
})

describe("MockDatabase - Purchase Operations", () => {
  beforeEach(async () => {
    await db.seed()
  })

  describe("createPurchase", () => {
    it("should create a purchase record", async () => {
      const purchase = await db.createPurchase({
        userId: "user-1",
        sweetId: "sweet-1",
        quantity: 5,
        totalPrice: 49.95,
      })

      expect(purchase.id).toBeDefined()
      expect(purchase.userId).toBe("user-1")
      expect(purchase.sweetId).toBe("sweet-1")
      expect(purchase.quantity).toBe(5)
      expect(purchase.totalPrice).toBe(49.95)
      expect(purchase.createdAt).toBeInstanceOf(Date)
    })
  })

  describe("findPurchasesByUserId", () => {
    it("should find all purchases for a user", async () => {
      await db.createPurchase({
        userId: "user-1",
        sweetId: "sweet-1",
        quantity: 2,
        totalPrice: 20,
      })

      await db.createPurchase({
        userId: "user-1",
        sweetId: "sweet-2",
        quantity: 3,
        totalPrice: 30,
      })

      await db.createPurchase({
        userId: "user-2",
        sweetId: "sweet-1",
        quantity: 1,
        totalPrice: 10,
      })

      const user1Purchases = await db.findPurchasesByUserId("user-1")
      expect(user1Purchases.length).toBe(2)
      expect(user1Purchases.every((p) => p.userId === "user-1")).toBe(true)
    })

    it("should return empty array for user with no purchases", async () => {
      const purchases = await db.findPurchasesByUserId("user-without-purchases")
      expect(purchases).toEqual([])
    })
  })
})
