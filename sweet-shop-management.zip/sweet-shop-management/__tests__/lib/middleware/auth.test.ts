// Unit tests for authentication middleware

import { requireAuth, requireAdmin } from "@/lib/middleware/auth"
import { signToken } from "@/lib/utils/jwt"
import { NextRequest } from "next/server"

function createMockRequest(token?: string): NextRequest {
  const headers: HeadersInit = { "Content-Type": "application/json" }
  if (token) {
    headers["Authorization"] = `Bearer ${token}`
  }

  return new NextRequest("http://localhost:3000/api/test", {
    method: "GET",
    headers,
  })
}

describe("Authentication Middleware", () => {
  describe("requireAuth", () => {
    it("should authorize valid user token", async () => {
      const token = await signToken({
        userId: "user-123",
        email: "user@test.com",
        role: "user",
      })

      const request = createMockRequest(token)
      const result = await requireAuth(request)

      expect(result.authorized).toBe(true)
      expect(result.user).toBeDefined()
      expect(result.user?.userId).toBe("user-123")
      expect(result.user?.role).toBe("user")
    })

    it("should authorize valid admin token", async () => {
      const token = await signToken({
        userId: "admin-123",
        email: "admin@test.com",
        role: "admin",
      })

      const request = createMockRequest(token)
      const result = await requireAuth(request)

      expect(result.authorized).toBe(true)
      expect(result.user?.role).toBe("admin")
    })

    it("should reject request without authorization header", async () => {
      const request = createMockRequest()
      const result = await requireAuth(request)

      expect(result.authorized).toBe(false)
      expect(result.user).toBeUndefined()
    })

    it("should reject request with malformed authorization header", async () => {
      const headers: HeadersInit = {
        "Content-Type": "application/json",
        Authorization: "InvalidFormat token",
      }

      const request = new NextRequest("http://localhost:3000/api/test", {
        method: "GET",
        headers,
      })

      const result = await requireAuth(request)
      expect(result.authorized).toBe(false)
    })

    it("should reject request with invalid token", async () => {
      const request = createMockRequest("invalid-token-string")
      const result = await requireAuth(request)

      expect(result.authorized).toBe(false)
      expect(result.user).toBeUndefined()
    })
  })

  describe("requireAdmin", () => {
    it("should authorize valid admin token", async () => {
      const token = await signToken({
        userId: "admin-123",
        email: "admin@test.com",
        role: "admin",
      })

      const request = createMockRequest(token)
      const result = await requireAdmin(request)

      expect(result.authorized).toBe(true)
      expect(result.user?.role).toBe("admin")
    })

    it("should reject user token (non-admin)", async () => {
      const token = await signToken({
        userId: "user-123",
        email: "user@test.com",
        role: "user",
      })

      const request = createMockRequest(token)
      const result = await requireAdmin(request)

      expect(result.authorized).toBe(false)
    })

    it("should reject request without token", async () => {
      const request = createMockRequest()
      const result = await requireAdmin(request)

      expect(result.authorized).toBe(false)
      expect(result.user).toBeUndefined()
    })

    it("should reject request with invalid token", async () => {
      const request = createMockRequest("invalid-token")
      const result = await requireAdmin(request)

      expect(result.authorized).toBe(false)
    })
  })
})
