// Unit tests for JWT utilities

import { signToken, verifyToken } from "@/lib/utils/jwt"

describe("JWT Utilities", () => {
  const mockPayload = {
    userId: "user-123",
    email: "test@example.com",
    role: "user" as const,
  }

  describe("signToken", () => {
    it("should generate a valid JWT token", async () => {
      const token = await signToken(mockPayload)

      expect(token).toBeDefined()
      expect(typeof token).toBe("string")
      expect(token.split(".").length).toBe(3) // JWT format: header.payload.signature
    })

    it("should generate different tokens for same payload", async () => {
      const token1 = await signToken(mockPayload)
      await new Promise((resolve) => setTimeout(resolve, 10))
      const token2 = await signToken(mockPayload)

      // Tokens should be different due to different 'iat' (issued at) claim
      expect(token1).not.toBe(token2)
    })
  })

  describe("verifyToken", () => {
    it("should verify valid token and return payload", async () => {
      const token = await signToken(mockPayload)
      const payload = await verifyToken(token)

      expect(payload).not.toBeNull()
      expect(payload?.userId).toBe(mockPayload.userId)
      expect(payload?.email).toBe(mockPayload.email)
      expect(payload?.role).toBe(mockPayload.role)
    })

    it("should return null for invalid token", async () => {
      const payload = await verifyToken("invalid-token-string")
      expect(payload).toBeNull()
    })

    it("should return null for malformed token", async () => {
      const payload = await verifyToken("not.a.valid.jwt.format")
      expect(payload).toBeNull()
    })

    it("should return null for empty token", async () => {
      const payload = await verifyToken("")
      expect(payload).toBeNull()
    })

    it("should handle token with different payload structure", async () => {
      const adminPayload = {
        userId: "admin-456",
        email: "admin@example.com",
        role: "admin" as const,
      }

      const token = await signToken(adminPayload)
      const payload = await verifyToken(token)

      expect(payload?.role).toBe("admin")
    })
  })

  describe("Token Expiration", () => {
    it("should include expiration in token", async () => {
      const token = await signToken(mockPayload)
      const payload = await verifyToken(token)

      expect(payload).not.toBeNull()
      // Token should be valid immediately after creation
    })
  })
})
