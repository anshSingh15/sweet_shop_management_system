// Unit tests for password utilities

import { hashPassword, comparePassword } from "@/lib/utils/password"

describe("Password Utilities", () => {
  describe("hashPassword", () => {
    it("should hash a password", async () => {
      const password = "testpassword123"
      const hash = await hashPassword(password)

      expect(hash).toBeDefined()
      expect(hash).not.toBe(password)
      expect(hash.length).toBeGreaterThan(0)
    })

    it("should generate different hashes for same password", async () => {
      const password = "testpassword123"
      const hash1 = await hashPassword(password)
      const hash2 = await hashPassword(password)

      // Bcrypt uses salts, so same password should produce different hashes
      expect(hash1).not.toBe(hash2)
    })

    it("should handle empty password", async () => {
      const hash = await hashPassword("")
      expect(hash).toBeDefined()
    })
  })

  describe("comparePassword", () => {
    it("should return true for correct password", async () => {
      const password = "testpassword123"
      const hash = await hashPassword(password)

      const isValid = await comparePassword(password, hash)
      expect(isValid).toBe(true)
    })

    it("should return false for incorrect password", async () => {
      const password = "testpassword123"
      const hash = await hashPassword(password)

      const isValid = await comparePassword("wrongpassword", hash)
      expect(isValid).toBe(false)
    })

    it("should be case-sensitive", async () => {
      const password = "TestPassword123"
      const hash = await hashPassword(password)

      const isValid = await comparePassword("testpassword123", hash)
      expect(isValid).toBe(false)
    })

    it("should handle empty password comparison", async () => {
      const hash = await hashPassword("")
      const isValid = await comparePassword("", hash)
      expect(isValid).toBe(true)
    })
  })
})
